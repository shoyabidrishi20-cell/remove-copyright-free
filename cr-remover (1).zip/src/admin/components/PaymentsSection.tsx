import { useState } from 'react';
import { Download, Search } from 'lucide-react';
import {
  AdminPaymentRecord,
  PAYMENT_STATUS_LABELS,
  PaymentVerificationStatus,
  UPI_APP_LABELS,
  UpiChannel,
  filterPayments,
  formatInr,
  formatIsoDate,
  paymentsToCsv,
} from '../utils/adminLogic';

interface PaymentsSectionProps {
  payments: AdminPaymentRecord[];
  onVerifyPayment: (
    paymentId: string,
    status: PaymentVerificationStatus,
    notes: string
  ) => Promise<void>;
}

export function PaymentsSection({ payments, onVerifyPayment }: PaymentsSectionProps) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<PaymentVerificationStatus | 'all'>('all');
  const [appFilter, setAppFilter] = useState<UpiChannel | 'all'>('all');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const filtered = filterPayments(payments, search, statusFilter, appFilter);

  async function handleStatusAction(payment: AdminPaymentRecord, next: PaymentVerificationStatus) {
    setBusyId(payment.paymentId);
    setActionError(null);
    try {
      await onVerifyPayment(payment.paymentId, next, payment.notes || `Updated to ${next}`);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to update payment.');
    } finally {
      setBusyId(null);
    }
  }

  function handleExportCsv() {
    const csv = paymentsToCsv(filtered);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'cr-remover-payments.csv';
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-950">Payment Management</h1>
          <p className="mt-1 text-sm text-slate-600">
            Verify 12-digit UPI UTR references across PhonePe, Google Pay, Paytm, and BHIM UPI.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportCsv}
          disabled={filtered.length === 0}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 disabled:opacity-50 rounded-lg cursor-pointer whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export CSV</span>
        </button>
      </div>

      {actionError && (
        <p role="alert" className="text-sm font-medium text-red-700">
          {actionError}
        </p>
      )}

      {/* Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 grid grid-cols-1 md:grid-cols-12 gap-3">
        <div className="md:col-span-6 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            aria-label="Search payments"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by UTR number, Case ID, or payer name..."
            className="w-full pl-9 pr-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
          />
        </div>
        <div className="md:col-span-3">
          <select
            aria-label="Filter payments by verification status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as PaymentVerificationStatus | 'all')}
            className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:border-[#1E40AF]"
          >
            <option value="all">All Verification States</option>
            <option value="pending">Pending Review</option>
            <option value="verified">Verified</option>
            <option value="rejected">Rejected</option>
            <option value="refunded">Refunded</option>
          </select>
        </div>
        <div className="md:col-span-3">
          <select
            aria-label="Filter payments by UPI channel"
            value={appFilter}
            onChange={(e) => setAppFilter(e.target.value as UpiChannel | 'all')}
            className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:border-[#1E40AF]"
          >
            <option value="all">All UPI Apps</option>
            <option value="phonepe">PhonePe</option>
            <option value="gpay">Google Pay</option>
            <option value="paytm">Paytm</option>
            <option value="qr">BHIM UPI</option>
          </select>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm font-semibold text-slate-900">
              {payments.length === 0 ? 'No payment records recorded yet' : 'No matching payments'}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Real UPI UTR proofs submitted for claim orders will populate this ledger automatically.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">UTR Reference</th>
                  <th className="py-3 px-4">Case &amp; Payer</th>
                  <th className="py-3 px-4">UPI App</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Submitted</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((payment) => (
                  <tr key={payment.paymentId} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono tabular-nums font-semibold text-slate-950 whitespace-nowrap">
                      {payment.utrNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-mono text-xs font-semibold text-slate-800">
                        {payment.caseId}
                      </div>
                      <div className="text-xs text-slate-500">{payment.payerName}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-700 whitespace-nowrap">
                      {UPI_APP_LABELS[payment.paymentApp]}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-950 whitespace-nowrap">
                      {formatInr(payment.amountInr)}
                    </td>
                    <td className="py-3 px-4 text-xs font-semibold whitespace-nowrap">
                      <span
                        className={
                          payment.verificationStatus === 'verified'
                            ? 'text-emerald-700'
                            : payment.verificationStatus === 'rejected'
                              ? 'text-red-700'
                              : payment.verificationStatus === 'pending'
                                ? 'text-amber-700'
                                : 'text-slate-700'
                        }
                      >
                        {PAYMENT_STATUS_LABELS[payment.verificationStatus]}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-500 font-mono tabular-nums whitespace-nowrap">
                      {formatIsoDate(payment.createdAt)}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          disabled={busyId === payment.paymentId || payment.verificationStatus === 'verified'}
                          onClick={() => handleStatusAction(payment, 'verified')}
                          className="px-2.5 py-1 text-xs font-semibold text-emerald-700 border border-emerald-300 hover:bg-emerald-50 disabled:opacity-40 rounded-md cursor-pointer whitespace-nowrap"
                        >
                          Verify
                        </button>
                        <button
                          type="button"
                          disabled={busyId === payment.paymentId || payment.verificationStatus === 'rejected'}
                          onClick={() => handleStatusAction(payment, 'rejected')}
                          className="px-2.5 py-1 text-xs font-semibold text-red-700 border border-red-300 hover:bg-red-50 disabled:opacity-40 rounded-md cursor-pointer whitespace-nowrap"
                        >
                          Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
