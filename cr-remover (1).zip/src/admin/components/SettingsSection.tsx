import { FormEvent, useEffect, useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import { firebaseConfig } from '../firebase';
import {
  AuditLogDoc,
  SiteSettingsDoc,
  formatIsoDate,
  validateSettingsInput,
} from '../utils/adminLogic';

interface SettingsSectionProps {
  settings: SiteSettingsDoc | null;
  auditLogs: AuditLogDoc[];
  onSaveSettings: (next: SiteSettingsDoc) => Promise<void>;
}

const DEFAULT_SETTINGS: SiteSettingsDoc = {
  settingId: 'general',
  siteName: 'CR Remover',
  supportEmail: 'support@crremover.in',
  supportWhatsapp: '',
  upiDisplayLabel: 'CR Remover UPI QR',
  upiMerchantName: 'CR Remover',
  maintenanceMode: false,
  allowNewOrders: true,
  strictUtrValidation: true,
};

export function SettingsSection({
  settings,
  auditLogs,
  onSaveSettings,
}: SettingsSectionProps) {
  const [form, setForm] = useState<SiteSettingsDoc>(settings ?? DEFAULT_SETTINGS);
  const [saving, setSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (settings) {
      setForm(settings);
    }
  }, [settings]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const validationError = validateSettingsInput(form);
    if (validationError) {
      setError(validationError);
      return;
    }
    setError(null);
    setStatusMessage(null);
    setSaving(true);
    try {
      await onSaveSettings(form);
      setStatusMessage('Settings saved and audited in Firestore.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save settings.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-950">
          Website Settings
        </h1>
        <p className="mt-1 text-sm text-slate-600">
          Configure operational website controls and review server-side authorization audit logs.
        </p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleSubmit}
          className="xl:col-span-6 bg-white border border-slate-200 rounded-xl p-6 space-y-5"
        >
          <h2 className="text-base font-bold text-slate-950">General &amp; Checkout Settings</h2>

          <div className="space-y-4">
            <div>
              <label htmlFor="set-site-name" className="block text-sm font-medium text-slate-800 mb-1">
                Website Name
              </label>
              <input
                id="set-site-name"
                type="text"
                required
                maxLength={80}
                value={form.siteName}
                onChange={(e) => setForm({ ...form, siteName: e.target.value })}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="set-support-email"
                  className="block text-sm font-medium text-slate-800 mb-1"
                >
                  Support Email
                </label>
                <input
                  id="set-support-email"
                  type="email"
                  required
                  maxLength={160}
                  value={form.supportEmail}
                  onChange={(e) => setForm({ ...form, supportEmail: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
                />
              </div>
              <div>
                <label
                  htmlFor="set-support-whatsapp"
                  className="block text-sm font-medium text-slate-800 mb-1"
                >
                  Support WhatsApp
                </label>
                <input
                  id="set-support-whatsapp"
                  type="text"
                  maxLength={32}
                  value={form.supportWhatsapp}
                  onChange={(e) => setForm({ ...form, supportWhatsapp: e.target.value })}
                  placeholder="+91 ..."
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="set-upi-label"
                  className="block text-sm font-medium text-slate-800 mb-1"
                >
                  UPI QR Display Label
                </label>
                <input
                  id="set-upi-label"
                  type="text"
                  required
                  maxLength={80}
                  value={form.upiDisplayLabel}
                  onChange={(e) => setForm({ ...form, upiDisplayLabel: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
                />
              </div>
              <div>
                <label
                  htmlFor="set-upi-merchant"
                  className="block text-sm font-medium text-slate-800 mb-1"
                >
                  UPI Merchant Name
                </label>
                <input
                  id="set-upi-merchant"
                  type="text"
                  required
                  maxLength={80}
                  value={form.upiMerchantName}
                  onChange={(e) => setForm({ ...form, upiMerchantName: e.target.value })}
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
                />
              </div>
            </div>

            <div className="space-y-2.5 pt-2 border-t border-slate-100">
              <label className="flex items-center gap-2.5 text-sm text-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.allowNewOrders}
                  onChange={(e) => setForm({ ...form, allowNewOrders: e.target.checked })}
                  className="rounded border-slate-300"
                />
                <span>Accept new copyright claim orders on main website</span>
              </label>

              <label className="flex items-center gap-2.5 text-sm text-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.strictUtrValidation}
                  onChange={(e) => setForm({ ...form, strictUtrValidation: e.target.checked })}
                  className="rounded border-slate-300"
                />
                <span>Enforce strict 12-digit numeric UTR validation</span>
              </label>

              <label className="flex items-center gap-2.5 text-sm text-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.maintenanceMode}
                  onChange={(e) => setForm({ ...form, maintenanceMode: e.target.checked })}
                  className="rounded border-slate-300"
                />
                <span>Enable maintenance notice on public checkout</span>
              </label>
            </div>
          </div>

          {error && (
            <p role="alert" className="text-xs font-medium text-red-700">
              {error}
            </p>
          )}
          {statusMessage && <p className="text-xs font-medium text-emerald-700">{statusMessage}</p>}

          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] disabled:opacity-60 rounded-lg cursor-pointer"
          >
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </form>

        {/* Backend Architecture & Security Summary (no secrets) */}
        <div className="xl:col-span-6 space-y-6">
          <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-[#1E40AF]" />
              <h2 className="text-base font-bold text-slate-950">Backend &amp; Security Configuration</h2>
            </div>
            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-lg">
              <div>
                <dt className="text-slate-500">Firebase Project ID</dt>
                <dd className="font-mono font-semibold text-slate-900 mt-1">
                  {firebaseConfig.projectId}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Firestore Database ID</dt>
                <dd className="font-mono font-semibold text-slate-900 mt-1 break-all">
                  {firebaseConfig.firestoreDatabaseId}
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Server Token Verification</dt>
                <dd className="font-semibold text-emerald-700 mt-1">
                  RS256 Firebase ID Token + Admin RBAC
                </dd>
              </div>
              <div>
                <dt className="text-slate-500">Client Secrets Exposure</dt>
                <dd className="font-semibold text-emerald-700 mt-1">
                  None (zero admin credentials in frontend)
                </dd>
              </div>
            </dl>
          </section>

          <section className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-950">Immutable Audit Logs</h2>
            </div>

            {auditLogs.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-sm font-medium text-slate-900">No audit entries yet</p>
                <p className="mt-1 text-xs text-slate-500">
                  Admin actions create append-only records in `/auditLogs`.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
                {auditLogs.map((log) => (
                  <div key={log.logId} className="px-5 py-3 text-xs space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-slate-900">{log.action}</span>
                      <span className="font-mono tabular-nums text-slate-500">
                        {formatIsoDate(log.createdAt)}
                      </span>
                    </div>
                    <p className="text-slate-700">{log.summary}</p>
                    <p className="text-slate-500">{log.actorEmail}</p>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
