import { useState } from 'react';
import { Download, Search, X } from 'lucide-react';
import {
  AdminOrder,
  ORDER_STATUS_LABELS,
  OrderStatus,
  UPI_APP_LABELS,
  filterOrders,
  formatInr,
  formatIsoDate,
  ordersToCsv,
} from '../utils/adminLogic';

interface OrdersSectionProps {
  orders: AdminOrder[];
  onUpdateOrder: (
    caseId: string,
    updates: { status: OrderStatus; adminNotes: string }
  ) => Promise<void>;
}

const STATUS_OPTIONS: OrderStatus[] = [
  'awaiting_payment',
  'verifying_payment',
  'dispute_filed',
  'claim_released',
  'rejected',
];

export function OrdersSection({ orders, onUpdateOrder }: OrdersSectionProps) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [platformFilter, setPlatformFilter] = useState<AdminOrder['platform'] | 'all'>('all');

  const [editingOrder, setEditingOrder] = useState<AdminOrder | null>(null);
  const [nextStatus, setNextStatus] = useState<OrderStatus>('verifying_payment');
  const [nextNotes, setNextNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const filtered = filterOrders(orders, search, statusFilter, platformFilter);

  function openEditor(order: AdminOrder) {
    setEditingOrder(order);
    setNextStatus(order.status);
    setNextNotes(order.adminNotes ?? '');
    setSaveError(null);
  }

  async function handleSaveOrder() {
    if (!editingOrder) return;
    setSaving(true);
    setSaveError(null);
    try {
      await onUpdateOrder(editingOrder.caseId, {
        status: nextStatus,
        adminNotes: nextNotes,
      });
      setEditingOrder(null);
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Failed to update order.');
    } finally {
      setSaving(false);
    }
  }

  function handleExportCsv() {
    const csv = ordersToCsv(filtered);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'cr-remover-orders.csv';
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-950">Order History</h1>
          <p className="mt-1 text-sm text-slate-600">
            Review claim submissions, verify payment status, and update dispute progress.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportCsv}
          disabled={filtered.length === 0}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-800 bg-white border border-slate-300 hover:bg-slate-50 disabled:opacity-50 rounded-lg cursor-pointer whitespace-nowrap shrink-0"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 grid grid-cols-1 md:grid-cols-12 gap-3">
        <div className="md:col-span-6 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            aria-label="Search orders"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Case ID, creator, UTR, or video URL..."
            className="w-full pl-9 pr-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
          />
        </div>
        <div className="md:col-span-3">
          <select
            aria-label="Filter orders by status"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as OrderStatus | 'all')}
            className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:border-[#1E40AF]"
          >
            <option value="all">All Statuses</option>
            {STATUS_OPTIONS.map((status) => (
              <option key={status} value={status}>
                {ORDER_STATUS_LABELS[status]}
              </option>
            ))}
          </select>
        </div>
        <div className="md:col-span-3">
          <select
            aria-label="Filter orders by platform"
            value={platformFilter}
            onChange={(e) => setPlatformFilter(e.target.value as AdminOrder['platform'] | 'all')}
            className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:border-[#1E40AF]"
          >
            <option value="all">All Platforms</option>
            <option value="YouTube">YouTube</option>
            <option value="Instagram Reels">Instagram Reels</option>
            <option value="Facebook Video">Facebook Video</option>
            <option value="YouTube Shorts">YouTube Shorts</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-10 text-center">
            <p className="text-sm font-semibold text-slate-900">
              {orders.length === 0 ? 'No orders in Firestore yet' : 'No orders match these filters'}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              {orders.length === 0
                ? 'Orders created on the main website will appear here automatically once submitted.'
                : 'Clear or adjust your search criteria to view all recorded orders.'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">Case ID</th>
                  <th className="py-3 px-4">Creator &amp; Platform</th>
                  <th className="py-3 px-4">Service</th>
                  <th className="py-3 px-4">UPI / UTR</th>
                  <th className="py-3 px-4 text-right">Fee</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filtered.map((order) => (
                  <tr key={order.caseId} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono tabular-nums font-semibold text-slate-950 whitespace-nowrap">
                      {order.caseId}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-900">{order.creatorName}</div>
                      <div className="text-xs text-slate-500">
                        {order.platform} · {order.contact}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-slate-700">{order.serviceTitle}</td>
                    <td className="py-3 px-4 font-mono tabular-nums text-xs text-slate-700">
                      <div>{UPI_APP_LABELS[order.paymentApp]}</div>
                      <div className="text-slate-500">{order.utrNumber || 'Pending UTR'}</div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold text-slate-950 whitespace-nowrap">
                      {formatInr(order.amountInr)}
                    </td>
                    <td className="py-3 px-4 text-xs font-semibold whitespace-nowrap">
                      <span
                        className={
                          order.status === 'claim_released'
                            ? 'text-emerald-700'
                            : order.status === 'rejected'
                              ? 'text-red-700'
                              : order.status === 'verifying_payment'
                                ? 'text-amber-700'
                                : 'text-slate-700'
                        }
                      >
                        {ORDER_STATUS_LABELS[order.status]}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => openEditor(order)}
                        className="px-3 py-1.5 text-xs font-semibold text-[#1E40AF] border border-[#1E40AF]/30 hover:bg-[#1E40AF]/5 rounded-lg cursor-pointer whitespace-nowrap"
                      >
                        Manage
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Order Modal */}
      {editingOrder && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`Manage order ${editingOrder.caseId}`}
          className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4"
          onClick={() => setEditingOrder(null)}
        >
          <div
            className="bg-white rounded-xl border border-slate-200 max-w-lg w-full p-6 space-y-5 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-950 font-mono tabular-nums">
                  {editingOrder.caseId}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Created {formatIsoDate(editingOrder.createdAt)}
                </p>
              </div>
              <button
                type="button"
                aria-label="Close order dialog"
                onClick={() => setEditingOrder(null)}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <dl className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-lg">
              <div>
                <dt className="text-slate-500">Creator</dt>
                <dd className="font-semibold text-slate-900 mt-0.5">{editingOrder.creatorName}</dd>
              </div>
              <div>
                <dt className="text-slate-500">Fee</dt>
                <dd className="font-semibold text-slate-900 font-mono tabular-nums mt-0.5">
                  {formatInr(editingOrder.amountInr)}
                </dd>
              </div>
              <div className="col-span-2">
                <dt className="text-slate-500">Video URL</dt>
                <dd className="font-medium text-slate-800 break-all mt-0.5">
                  {editingOrder.videoUrl}
                </dd>
              </div>
            </dl>

            <div className="space-y-4">
              <div>
                <label
                  htmlFor="order-status-select"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Order Status
                </label>
                <select
                  id="order-status-select"
                  value={nextStatus}
                  onChange={(e) => setNextStatus(e.target.value as OrderStatus)}
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:border-[#1E40AF]"
                >
                  {STATUS_OPTIONS.map((status) => (
                    <option key={status} value={status}>
                      {ORDER_STATUS_LABELS[status]}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="order-admin-notes"
                  className="block text-sm font-medium text-slate-800 mb-1.5"
                >
                  Internal Admin Notes
                </label>
                <textarea
                  id="order-admin-notes"
                  rows={3}
                  maxLength={1000}
                  value={nextNotes}
                  onChange={(e) => setNextNotes(e.target.value)}
                  placeholder="Record dispute ticket number, claimant outreach status, or verification memo..."
                  className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
                />
              </div>
            </div>

            {saveError && (
              <p role="alert" className="text-xs font-medium text-red-700">
                {saveError}
              </p>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingOrder(null)}
                className="px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={saving}
                onClick={handleSaveOrder}
                className="px-4 py-2 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] disabled:opacity-60 rounded-lg cursor-pointer"
              >
                {saving ? 'Saving...' : 'Save Order Update'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
