import { useState, type ReactNode } from 'react';
import {
  BarChart3,
  CreditCard,
  ExternalLink,
  FileEdit,
  LayoutDashboard,
  LogOut,
  Menu,
  RefreshCw,
  Settings,
  ShoppingBag,
  Users,
  X,
} from 'lucide-react';

export type AdminSectionId =
  | 'overview'
  | 'orders'
  | 'payments'
  | 'users'
  | 'analytics'
  | 'content'
  | 'settings';

export interface AdminNavItem {
  id: AdminSectionId;
  label: string;
  path: string;
}

export const ADMIN_NAV_ITEMS: AdminNavItem[] = [
  { id: 'overview', label: 'Dashboard', path: '/admin/dashboard' },
  { id: 'orders', label: 'Order History', path: '/admin/orders' },
  { id: 'payments', label: 'Payments', path: '/admin/payments' },
  { id: 'users', label: 'Users', path: '/admin/users' },
  { id: 'analytics', label: 'Analytics', path: '/admin/analytics' },
  { id: 'content', label: 'Content', path: '/admin/content' },
  { id: 'settings', label: 'Settings', path: '/admin/settings' },
];

function NavIcon({ id }: { id: AdminSectionId }) {
  const cls = 'w-4 h-4 shrink-0';
  switch (id) {
    case 'overview':
      return <LayoutDashboard className={cls} />;
    case 'orders':
      return <ShoppingBag className={cls} />;
    case 'payments':
      return <CreditCard className={cls} />;
    case 'users':
      return <Users className={cls} />;
    case 'analytics':
      return <BarChart3 className={cls} />;
    case 'content':
      return <FileEdit className={cls} />;
    case 'settings':
      return <Settings className={cls} />;
  }
}

interface AdminShellProps {
  activeSection: AdminSectionId;
  onNavigate: (section: AdminSectionId) => void;
  adminEmail: string;
  adminRole: string;
  refreshing: boolean;
  onRefresh: () => void;
  onSignOut: () => void;
  children: ReactNode;
}

export function AdminShell({
  activeSection,
  onNavigate,
  adminEmail,
  adminRole,
  refreshing,
  onRefresh,
  onSignOut,
  children,
}: AdminShellProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeItem = ADMIN_NAV_ITEMS.find((item) => item.id === activeSection) ?? ADMIN_NAV_ITEMS[0];

  function handleSelect(id: AdminSectionId) {
    onNavigate(id);
    setMobileMenuOpen(false);
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col w-64 shrink-0 bg-[#0F172A] text-slate-200 border-r border-slate-800">
        <div className="h-16 px-6 flex items-center border-b border-slate-800">
          <a
            href="/admin"
            onClick={(e) => {
              e.preventDefault();
              handleSelect('overview');
            }}
            className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0"
          >
            CR Remover Admin
          </a>
        </div>

        <nav aria-label="Admin navigation" className="flex-1 p-4 space-y-1">
          {ADMIN_NAV_ITEMS.map((item) => {
            const active = item.id === activeSection;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-[#1E40AF] text-white'
                    : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
                }`}
              >
                <NavIcon id={item.id} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-800 space-y-3">
          <div className="text-xs text-slate-400">
            <div className="font-medium text-slate-200 truncate">{adminEmail}</div>
            <div className="mt-0.5 capitalize">{adminRole.replace('_', ' ')}</div>
          </div>
          <a
            href="/"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full inline-flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <span>Open Main Website</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-10 w-64 max-w-[80vw] bg-[#0F172A] text-slate-200 flex flex-col h-full">
            <div className="h-16 px-5 flex items-center justify-between border-b border-slate-800">
              <span className="text-base font-bold text-white whitespace-nowrap">
                CR Remover Admin
              </span>
              <button
                type="button"
                aria-label="Close navigation menu"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav aria-label="Mobile admin navigation" className="flex-1 p-4 space-y-1">
              {ADMIN_NAV_ITEMS.map((item) => {
                const active = item.id === activeSection;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelect(item.id)}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      active
                        ? 'bg-[#1E40AF] text-white'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <NavIcon id={item.id} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-slate-800 space-y-2">
              <div className="text-xs text-slate-300 truncate">{adminEmail}</div>
              <button
                type="button"
                onClick={onSignOut}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 cursor-pointer whitespace-nowrap"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              aria-label="Open navigation menu"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-2 rounded-lg text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-slate-500 hidden sm:inline whitespace-nowrap">Admin</span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <span className="font-semibold text-slate-950 truncate">{activeItem.label}</span>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={onRefresh}
              disabled={refreshing}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg cursor-pointer whitespace-nowrap shrink-0 disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
              <span>Sync Data</span>
            </button>
            <button
              type="button"
              onClick={onSignOut}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-slate-950 hover:bg-slate-800 rounded-lg cursor-pointer whitespace-nowrap shrink-0"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1400px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
