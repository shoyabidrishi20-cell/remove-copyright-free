import { FormEvent, useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import {
  FaqItemDoc,
  ServicePlanDoc,
  SiteContentDoc,
  formatInr,
  validateFaqInput,
  validateServicePlanInput,
} from '../utils/adminLogic';

interface ContentSectionProps {
  siteContent: SiteContentDoc[];
  servicePlans: ServicePlanDoc[];
  faqs: FaqItemDoc[];
  onSaveHeroContent: (doc: SiteContentDoc) => Promise<void>;
  onSaveServicePlan: (plan: ServicePlanDoc) => Promise<void>;
  onDeleteServicePlan: (serviceId: string) => Promise<void>;
  onSaveFaq: (faq: FaqItemDoc) => Promise<void>;
  onDeleteFaq: (faqId: string) => Promise<void>;
}

const EMPTY_HERO: SiteContentDoc = {
  sectionId: 'hero',
  eyebrow: 'Creator Rights Desk · YouTube, Reels & Facebook',
  headline: 'Fast, verified copyright claim & strike removal for creators.',
  subheadline:
    'Clear false Content ID claims, muted Reels audio blocks, and active copyright strikes without sharing channel logins.',
  primaryCta: 'Remove a Copyright Claim',
  secondaryCta: 'Track Existing Case',
  qrImageUrl: '/assets/aistudio/1794605881633_020ec386.png',
  footerTagline: 'Creator Rights & Copyright Claim Clearance Desk · UPI QR Verified',
};

export function ContentSection({
  siteContent,
  servicePlans,
  faqs,
  onSaveHeroContent,
  onSaveServicePlan,
  onDeleteServicePlan,
  onSaveFaq,
  onDeleteFaq,
}: ContentSectionProps) {
  const [activeTab, setActiveTab] = useState<'hero' | 'plans' | 'faqs'>('hero');

  const existingHero = siteContent.find((c) => c.sectionId === 'hero') ?? EMPTY_HERO;
  const [heroForm, setHeroForm] = useState<SiteContentDoc>(existingHero);
  const [heroSaving, setHeroSaving] = useState(false);
  const [heroMessage, setHeroMessage] = useState<string | null>(null);

  useEffect(() => {
    const found = siteContent.find((c) => c.sectionId === 'hero');
    if (found) setHeroForm(found);
  }, [siteContent]);

  // Service Plan Editor state
  const [planForm, setPlanForm] = useState<ServicePlanDoc>({
    serviceId: '',
    code: '01',
    title: '',
    subtitle: '',
    priceInr: 149,
    turnaround: '24-48 hours',
    scope: '1 Claim',
    active: true,
    sortOrder: servicePlans.length + 1,
  });
  const [planError, setPlanError] = useState<string | null>(null);
  const [planSaving, setPlanSaving] = useState(false);

  // FAQ Editor state
  const [faqForm, setFaqForm] = useState<FaqItemDoc>({
    faqId: '',
    question: '',
    answer: '',
    sortOrder: faqs.length + 1,
    active: true,
  });
  const [faqError, setFaqError] = useState<string | null>(null);
  const [faqSaving, setFaqSaving] = useState(false);

  async function handleHeroSubmit(e: FormEvent) {
    e.preventDefault();
    setHeroSaving(true);
    setHeroMessage(null);
    try {
      await onSaveHeroContent({ ...heroForm, sectionId: 'hero' });
      setHeroMessage('Website copy saved to Firestore.');
    } catch (err) {
      setHeroMessage(err instanceof Error ? err.message : 'Failed to save content.');
    } finally {
      setHeroSaving(false);
    }
  }

  async function handlePlanSubmit(e: FormEvent) {
    e.preventDefault();
    const validationErr = validateServicePlanInput(planForm);
    if (validationErr) {
      setPlanError(validationErr);
      return;
    }
    setPlanError(null);
    setPlanSaving(true);
    try {
      await onSaveServicePlan(planForm);
      setPlanForm({
        serviceId: '',
        code: String(servicePlans.length + 2).padStart(2, '0'),
        title: '',
        subtitle: '',
        priceInr: 499,
        turnaround: '24-48 hours',
        scope: '1 Claim',
        active: true,
        sortOrder: servicePlans.length + 2,
      });
    } catch (err) {
      setPlanError(err instanceof Error ? err.message : 'Failed to save service plan.');
    } finally {
      setPlanSaving(false);
    }
  }

  async function handleFaqSubmit(e: FormEvent) {
    e.preventDefault();
    const validationErr = validateFaqInput(faqForm);
    if (validationErr) {
      setFaqError(validationErr);
      return;
    }
    setFaqError(null);
    setFaqSaving(true);
    try {
      await onSaveFaq(faqForm);
      setFaqForm({
        faqId: '',
        question: '',
        answer: '',
        sortOrder: faqs.length + 2,
        active: true,
      });
    } catch (err) {
      setFaqError(err instanceof Error ? err.message : 'Failed to save FAQ item.');
    } finally {
      setFaqSaving(false);
    }
  }

  const sortedPlans = [...servicePlans].sort((a, b) => a.sortOrder - b.sortOrder);
  const sortedFaqs = [...faqs].sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-950">Website Content CMS</h1>
        <p className="mt-1 text-sm text-slate-600">
          Edit hero messaging, service plans, pricing in INR, QR asset reference, and FAQs stored in
          the shared Firestore database.
        </p>
      </div>

      {/* Sub-navigation tabs */}
      <div className="inline-flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
        <button
          type="button"
          onClick={() => setActiveTab('hero')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
            activeTab === 'hero'
              ? 'bg-white text-slate-950 shadow-sm'
              : 'text-slate-600 hover:text-slate-950'
          }`}
        >
          Hero &amp; QR Copy
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('plans')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
            activeTab === 'plans'
              ? 'bg-white text-slate-950 shadow-sm'
              : 'text-slate-600 hover:text-slate-950'
          }`}
        >
          Service Plans ({servicePlans.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('faqs')}
          className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer whitespace-nowrap ${
            activeTab === 'faqs'
              ? 'bg-white text-slate-950 shadow-sm'
              : 'text-slate-600 hover:text-slate-950'
          }`}
        >
          FAQs ({faqs.length})
        </button>
      </div>

      {activeTab === 'hero' && (
        <form
          onSubmit={handleHeroSubmit}
          className="bg-white border border-slate-200 rounded-xl p-6 space-y-5 max-w-3xl"
        >
          <div>
            <h2 className="text-base font-bold text-slate-950">Homepage Hero &amp; QR Config</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Published at Firestore path `/siteContent/hero` and `/api/public/site-config`.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label htmlFor="cms-eyebrow" className="block text-sm font-medium text-slate-800 mb-1.5">
                Hero Eyebrow Text
              </label>
              <input
                id="cms-eyebrow"
                type="text"
                maxLength={120}
                value={heroForm.eyebrow}
                onChange={(e) => setHeroForm({ ...heroForm, eyebrow: e.target.value })}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
              />
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="cms-headline" className="block text-sm font-medium text-slate-800 mb-1.5">
                Primary Headline
              </label>
              <input
                id="cms-headline"
                type="text"
                required
                maxLength={220}
                value={heroForm.headline}
                onChange={(e) => setHeroForm({ ...heroForm, headline: e.target.value })}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
              />
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="cms-subheadline" className="block text-sm font-medium text-slate-800 mb-1.5">
                Hero Subheadline
              </label>
              <textarea
                id="cms-subheadline"
                rows={3}
                maxLength={500}
                value={heroForm.subheadline}
                onChange={(e) => setHeroForm({ ...heroForm, subheadline: e.target.value })}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
              />
            </div>

            <div>
              <label htmlFor="cms-cta-primary" className="block text-sm font-medium text-slate-800 mb-1.5">
                Primary CTA Label
              </label>
              <input
                id="cms-cta-primary"
                type="text"
                maxLength={80}
                value={heroForm.primaryCta}
                onChange={(e) => setHeroForm({ ...heroForm, primaryCta: e.target.value })}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
              />
            </div>

            <div>
              <label htmlFor="cms-cta-secondary" className="block text-sm font-medium text-slate-800 mb-1.5">
                Secondary CTA Label
              </label>
              <input
                id="cms-cta-secondary"
                type="text"
                maxLength={80}
                value={heroForm.secondaryCta}
                onChange={(e) => setHeroForm({ ...heroForm, secondaryCta: e.target.value })}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
              />
            </div>

            <div>
              <label htmlFor="cms-qr-url" className="block text-sm font-medium text-slate-800 mb-1.5">
                Active UPI QR Asset Path
              </label>
              <input
                id="cms-qr-url"
                type="text"
                maxLength={300}
                value={heroForm.qrImageUrl}
                onChange={(e) => setHeroForm({ ...heroForm, qrImageUrl: e.target.value })}
                className="w-full px-3.5 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
              />
            </div>

            <div>
              <label htmlFor="cms-footer" className="block text-sm font-medium text-slate-800 mb-1.5">
                Footer Tagline
              </label>
              <input
                id="cms-footer"
                type="text"
                maxLength={200}
                value={heroForm.footerTagline}
                onChange={(e) => setHeroForm({ ...heroForm, footerTagline: e.target.value })}
                className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#1E40AF]"
              />
            </div>
          </div>

          {heroMessage && <p className="text-xs font-medium text-slate-700">{heroMessage}</p>}

          <button
            type="submit"
            disabled={heroSaving}
            className="px-5 py-2.5 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] disabled:opacity-60 rounded-lg cursor-pointer"
          >
            {heroSaving ? 'Publishing...' : 'Publish Homepage Copy'}
          </button>
        </form>
      )}

      {activeTab === 'plans' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handlePlanSubmit}
            className="xl:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-slate-950">Add or Update Service Plan</h2>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="plan-id" className="block text-xs font-medium text-slate-700 mb-1">
                  Slug ID
                </label>
                <input
                  id="plan-id"
                  type="text"
                  required
                  value={planForm.serviceId}
                  onChange={(e) => setPlanForm({ ...planForm, serviceId: e.target.value })}
                  placeholder="shorts-basic-claim"
                  className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label htmlFor="plan-price" className="block text-xs font-medium text-slate-700 mb-1">
                  Price (INR)
                </label>
                <input
                  id="plan-price"
                  type="number"
                  min={1}
                  max={1000000}
                  required
                  value={planForm.priceInr}
                  onChange={(e) =>
                    setPlanForm({ ...planForm, priceInr: Number(e.target.value) || 0 })
                  }
                  className="w-full px-3 py-2 text-sm font-mono tabular-nums border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label htmlFor="plan-title" className="block text-xs font-medium text-slate-700 mb-1">
                Plan Title
              </label>
              <input
                id="plan-title"
                type="text"
                required
                value={planForm.title}
                onChange={(e) => setPlanForm({ ...planForm, title: e.target.value })}
                placeholder="Shorts & Single Clip Claim"
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label htmlFor="plan-subtitle" className="block text-xs font-medium text-slate-700 mb-1">
                Subtitle
              </label>
              <textarea
                id="plan-subtitle"
                rows={2}
                required
                value={planForm.subtitle}
                onChange={(e) => setPlanForm({ ...planForm, subtitle: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label htmlFor="plan-code" className="block text-xs font-medium text-slate-700 mb-1">
                  Code
                </label>
                <input
                  id="plan-code"
                  type="text"
                  value={planForm.code}
                  onChange={(e) => setPlanForm({ ...planForm, code: e.target.value })}
                  className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label
                  htmlFor="plan-turnaround"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Turnaround
                </label>
                <input
                  id="plan-turnaround"
                  type="text"
                  value={planForm.turnaround}
                  onChange={(e) => setPlanForm({ ...planForm, turnaround: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
              <div>
                <label htmlFor="plan-scope" className="block text-xs font-medium text-slate-700 mb-1">
                  Scope
                </label>
                <input
                  id="plan-scope"
                  type="text"
                  value={planForm.scope}
                  onChange={(e) => setPlanForm({ ...planForm, scope: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <label className="inline-flex items-center gap-2 text-sm text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={planForm.active}
                onChange={(e) => setPlanForm({ ...planForm, active: e.target.checked })}
                className="rounded border-slate-300"
              />
              <span>Published on main website</span>
            </label>

            {planError && (
              <p role="alert" className="text-xs font-medium text-red-700">
                {planError}
              </p>
            )}

            <button
              type="submit"
              disabled={planSaving}
              className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] disabled:opacity-60 rounded-lg inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{planSaving ? 'Saving...' : 'Save Service Plan'}</span>
            </button>
          </form>

          <div className="xl:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-950">Stored Service Plans</h2>
            </div>

            {sortedPlans.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-sm font-medium text-slate-900">No Firestore service plans yet</p>
                <p className="mt-1 text-xs text-slate-500">
                  Add a service plan using the form to publish live pricing to Cloud Firestore.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {sortedPlans.map((plan) => (
                  <div key={plan.serviceId} className="p-4 flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-slate-950">
                        {plan.code}. {plan.title}
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">{plan.subtitle}</p>
                      <div className="mt-1.5 text-xs text-slate-500 font-mono tabular-nums">
                        {plan.serviceId} · {plan.scope} · {plan.turnaround} ·{' '}
                        {plan.active ? 'Published' : 'Hidden'}
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="text-sm font-bold text-slate-950 font-mono tabular-nums">
                        {formatInr(plan.priceInr)}
                      </span>
                      <button
                        type="button"
                        onClick={() => setPlanForm(plan)}
                        className="px-2.5 py-1 text-xs font-semibold text-[#1E40AF] border border-[#1E40AF]/30 rounded-md cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete service plan ${plan.title}`}
                        onClick={() => onDeleteServicePlan(plan.serviceId)}
                        className="p-1.5 text-red-700 hover:bg-red-50 rounded-md cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'faqs' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          <form
            onSubmit={handleFaqSubmit}
            className="xl:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-slate-950">Add or Update FAQ</h2>
            <div>
              <label htmlFor="faq-id" className="block text-xs font-medium text-slate-700 mb-1">
                FAQ ID
              </label>
              <input
                id="faq-id"
                type="text"
                required
                value={faqForm.faqId}
                onChange={(e) => setFaqForm({ ...faqForm, faqId: e.target.value })}
                placeholder="upi-verification-time"
                className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="faq-question" className="block text-xs font-medium text-slate-700 mb-1">
                Question
              </label>
              <input
                id="faq-question"
                type="text"
                required
                value={faqForm.question}
                onChange={(e) => setFaqForm({ ...faqForm, question: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label htmlFor="faq-answer" className="block text-xs font-medium text-slate-700 mb-1">
                Answer
              </label>
              <textarea
                id="faq-answer"
                rows={4}
                required
                value={faqForm.answer}
                onChange={(e) => setFaqForm({ ...faqForm, answer: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>

            <label className="inline-flex items-center gap-2 text-sm text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={faqForm.active}
                onChange={(e) => setFaqForm({ ...faqForm, active: e.target.checked })}
                className="rounded border-slate-300"
              />
              <span>Visible on main website</span>
            </label>

            {faqError && (
              <p role="alert" className="text-xs font-medium text-red-700">
                {faqError}
              </p>
            )}

            <button
              type="submit"
              disabled={faqSaving}
              className="w-full py-2.5 px-4 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] disabled:opacity-60 rounded-lg inline-flex items-center justify-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{faqSaving ? 'Saving...' : 'Save FAQ Item'}</span>
            </button>
          </form>

          <div className="xl:col-span-7 bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200">
              <h2 className="text-base font-bold text-slate-950">Published FAQs</h2>
            </div>

            {sortedFaqs.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-sm font-medium text-slate-900">No Firestore FAQs yet</p>
                <p className="mt-1 text-xs text-slate-500">
                  Add FAQ items on the left to manage help answers from Cloud Firestore.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {sortedFaqs.map((faq) => (
                  <div key={faq.faqId} className="p-4 flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="text-sm font-bold text-slate-950">{faq.question}</div>
                      <p className="text-xs text-slate-600 mt-1">{faq.answer}</p>
                      <div className="mt-1.5 text-xs text-slate-500 font-mono">
                        {faq.faqId} · {faq.active ? 'Published' : 'Hidden'}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setFaqForm(faq)}
                        className="px-2.5 py-1 text-xs font-semibold text-[#1E40AF] border border-[#1E40AF]/30 rounded-md cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete FAQ ${faq.question}`}
                        onClick={() => onDeleteFaq(faq.faqId)}
                        className="p-1.5 text-red-700 hover:bg-red-50 rounded-md cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
