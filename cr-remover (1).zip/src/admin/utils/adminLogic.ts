export type OrderStatus =
  | 'awaiting_payment'
  | 'verifying_payment'
  | 'dispute_filed'
  | 'claim_released'
  | 'rejected';

export type PaymentVerificationStatus = 'pending' | 'verified' | 'rejected' | 'refunded';

export type UpiChannel = 'phonepe' | 'gpay' | 'paytm' | 'qr';

export interface AdminOrder {
  caseId: string;
  ownerUid: string;
  serviceId: string;
  serviceTitle: string;
  platform: 'YouTube' | 'Instagram Reels' | 'Facebook Video' | 'YouTube Shorts';
  videoUrl: string;
  claimantName: string;
  creatorName: string;
  contact: string;
  amountInr: number;
  status: OrderStatus;
  paymentApp: UpiChannel | 'none';
  utrNumber: string;
  adminNotes: string;
  createdAt?: string;
  updatedAt?: string;
  paidAt?: string;
}

export interface AdminPaymentRecord {
  paymentId: string;
  caseId: string;
  ownerUid: string;
  payerName: string;
  paymentApp: UpiChannel;
  utrNumber: string;
  amountInr: number;
  currency: 'INR';
  verificationStatus: PaymentVerificationStatus;
  verifiedByUid: string;
  notes: string;
  createdAt?: string;
  updatedAt?: string;
  verifiedAt?: string;
}

export interface AdminUserRecord {
  uid: string;
  displayName: string;
  channelName: string;
  role: 'creator' | 'moderator' | 'admin';
  status: 'active' | 'suspended';
  totalCases: number;
  email?: string;
  phone?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface AdminRoleRecord {
  uid: string;
  email: string;
  displayName: string;
  role: 'super_admin' | 'admin';
  active: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface SiteContentDoc {
  sectionId: string;
  eyebrow: string;
  headline: string;
  subheadline: string;
  primaryCta: string;
  secondaryCta: string;
  qrImageUrl: string;
  footerTagline: string;
  updatedByUid?: string;
  updatedAt?: string;
}

export interface ServicePlanDoc {
  serviceId: string;
  code: string;
  title: string;
  subtitle: string;
  priceInr: number;
  turnaround: string;
  scope: string;
  active: boolean;
  sortOrder: number;
  updatedAt?: string;
}

export interface FaqItemDoc {
  faqId: string;
  question: string;
  answer: string;
  sortOrder: number;
  active: boolean;
  updatedAt?: string;
}

export interface SiteSettingsDoc {
  settingId: string;
  siteName: string;
  supportEmail: string;
  supportWhatsapp: string;
  upiDisplayLabel: string;
  upiMerchantName: string;
  maintenanceMode: boolean;
  allowNewOrders: boolean;
  strictUtrValidation: boolean;
  updatedByUid?: string;
  updatedAt?: string;
}

export interface AnalyticsDailyDoc {
  dateKey: string;
  pageViews: number;
  checkoutStarts: number;
  ordersCreated: number;
  paymentsVerified: number;
  revenueInr: number;
  updatedAt?: string;
}

export interface AuditLogDoc {
  logId: string;
  actorUid: string;
  actorEmail: string;
  action: string;
  targetType: string;
  targetId: string;
  summary: string;
  createdAt?: string;
}

export interface DashboardSummaryStats {
  totalOrders: number;
  pendingOrders: number;
  releasedOrders: number;
  totalPayments: number;
  pendingPayments: number;
  verifiedPayments: number;
  verifiedRevenueInr: number;
  registeredUsers: number;
  activeAdmins: number;
}

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  awaiting_payment: 'Awaiting Payment',
  verifying_payment: 'Verifying UTR',
  dispute_filed: 'Dispute Filed',
  claim_released: 'Claim Released',
  rejected: 'Rejected',
};

export const PAYMENT_STATUS_LABELS: Record<PaymentVerificationStatus, string> = {
  pending: 'Pending Review',
  verified: 'Verified',
  rejected: 'Rejected',
  refunded: 'Refunded',
};

export const UPI_APP_LABELS: Record<UpiChannel | 'none', string> = {
  phonepe: 'PhonePe',
  gpay: 'Google Pay',
  paytm: 'Paytm',
  qr: 'BHIM UPI',
  none: 'Unselected',
};

export function formatInr(amount: number): string {
  return `₹${Math.round(amount).toLocaleString('en-IN')}`;
}

export function formatIsoDate(raw?: string): string {
  if (!raw) return '—';
  const parsed = new Date(raw);
  if (Number.isNaN(parsed.getTime())) return '—';
  return parsed.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function computeDashboardStats(params: {
  orders: AdminOrder[];
  payments: AdminPaymentRecord[];
  users: AdminUserRecord[];
  admins: AdminRoleRecord[];
}): DashboardSummaryStats {
  const { orders, payments, users, admins } = params;
  const pendingOrders = orders.filter(
    (o) => o.status === 'awaiting_payment' || o.status === 'verifying_payment'
  ).length;
  const releasedOrders = orders.filter((o) => o.status === 'claim_released').length;

  const verifiedList = payments.filter((p) => p.verificationStatus === 'verified');
  const pendingPayments = payments.filter((p) => p.verificationStatus === 'pending').length;
  const verifiedRevenueInr = verifiedList.reduce((acc, p) => acc + (Number(p.amountInr) || 0), 0);

  const activeAdmins = admins.filter((a) => a.active).length;

  return {
    totalOrders: orders.length,
    pendingOrders,
    releasedOrders,
    totalPayments: payments.length,
    pendingPayments,
    verifiedPayments: verifiedList.length,
    verifiedRevenueInr,
    registeredUsers: users.length,
    activeAdmins,
  };
}

export function computePlatformBreakdown(orders: AdminOrder[]): Array<{
  platform: AdminOrder['platform'];
  count: number;
  revenueInr: number;
}> {
  const platforms: AdminOrder['platform'][] = [
    'YouTube',
    'Instagram Reels',
    'Facebook Video',
    'YouTube Shorts',
  ];
  return platforms.map((platform) => {
    const matching = orders.filter((o) => o.platform === platform);
    return {
      platform,
      count: matching.length,
      revenueInr: matching.reduce((sum, o) => sum + (Number(o.amountInr) || 0), 0),
    };
  });
}

export function computePaymentChannelBreakdown(payments: AdminPaymentRecord[]): Array<{
  channel: UpiChannel;
  label: string;
  count: number;
  verifiedAmountInr: number;
}> {
  const channels: UpiChannel[] = ['phonepe', 'gpay', 'paytm', 'qr'];
  return channels.map((channel) => {
    const matching = payments.filter((p) => p.paymentApp === channel);
    const verifiedAmountInr = matching
      .filter((p) => p.verificationStatus === 'verified')
      .reduce((sum, p) => sum + (Number(p.amountInr) || 0), 0);
    return {
      channel,
      label: UPI_APP_LABELS[channel],
      count: matching.length,
      verifiedAmountInr,
    };
  });
}

export function filterOrders(
  orders: AdminOrder[],
  search: string,
  statusFilter: OrderStatus | 'all',
  platformFilter: AdminOrder['platform'] | 'all'
): AdminOrder[] {
  const q = search.trim().toLowerCase();
  return orders.filter((order) => {
    if (statusFilter !== 'all' && order.status !== statusFilter) return false;
    if (platformFilter !== 'all' && order.platform !== platformFilter) return false;
    if (!q) return true;
    return (
      order.caseId.toLowerCase().includes(q) ||
      order.creatorName.toLowerCase().includes(q) ||
      order.contact.toLowerCase().includes(q) ||
      order.utrNumber.toLowerCase().includes(q) ||
      order.serviceTitle.toLowerCase().includes(q) ||
      order.videoUrl.toLowerCase().includes(q)
    );
  });
}

export function filterPayments(
  payments: AdminPaymentRecord[],
  search: string,
  statusFilter: PaymentVerificationStatus | 'all',
  appFilter: UpiChannel | 'all'
): AdminPaymentRecord[] {
  const q = search.trim().toLowerCase();
  return payments.filter((p) => {
    if (statusFilter !== 'all' && p.verificationStatus !== statusFilter) return false;
    if (appFilter !== 'all' && p.paymentApp !== appFilter) return false;
    if (!q) return true;
    return (
      p.paymentId.toLowerCase().includes(q) ||
      p.caseId.toLowerCase().includes(q) ||
      p.utrNumber.toLowerCase().includes(q) ||
      p.payerName.toLowerCase().includes(q)
    );
  });
}

export function filterUsers(
  users: AdminUserRecord[],
  search: string,
  roleFilter: AdminUserRecord['role'] | 'all',
  statusFilter: AdminUserRecord['status'] | 'all'
): AdminUserRecord[] {
  const q = search.trim().toLowerCase();
  return users.filter((u) => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (statusFilter !== 'all' && u.status !== statusFilter) return false;
    if (!q) return true;
    return (
      u.uid.toLowerCase().includes(q) ||
      u.displayName.toLowerCase().includes(q) ||
      u.channelName.toLowerCase().includes(q) ||
      (u.email?.toLowerCase().includes(q) ?? false)
    );
  });
}

export function isValidSlugId(value: string): boolean {
  return /^[a-zA-Z0-9_\-]{1,64}$/.test(value.trim());
}

export function validateServicePlanInput(input: ServicePlanDoc): string | null {
  if (!isValidSlugId(input.serviceId)) {
    return 'Service ID must be 1–64 alphanumeric, underscore, or hyphen characters.';
  }
  if (input.title.trim().length < 2 || input.title.trim().length > 120) {
    return 'Title must be between 2 and 120 characters.';
  }
  if (input.subtitle.trim().length < 2 || input.subtitle.trim().length > 300) {
    return 'Subtitle must be between 2 and 300 characters.';
  }
  if (!Number.isFinite(input.priceInr) || input.priceInr < 1 || input.priceInr > 1000000) {
    return 'Price must be between ₹1 and ₹10,00,000.';
  }
  return null;
}

export function validateFaqInput(input: FaqItemDoc): string | null {
  if (!isValidSlugId(input.faqId)) {
    return 'FAQ ID must be 1–64 alphanumeric, underscore, or hyphen characters.';
  }
  if (input.question.trim().length < 5 || input.question.trim().length > 240) {
    return 'Question must be between 5 and 240 characters.';
  }
  if (input.answer.trim().length < 5 || input.answer.trim().length > 1200) {
    return 'Answer must be between 5 and 1,200 characters.';
  }
  return null;
}

export function validateSettingsInput(input: SiteSettingsDoc): string | null {
  if (input.siteName.trim().length < 1 || input.siteName.trim().length > 80) {
    return 'Site name is required (1–80 characters).';
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(input.supportEmail.trim())) {
    return 'Enter a valid support email address.';
  }
  if (input.upiDisplayLabel.trim().length < 1 || input.upiDisplayLabel.trim().length > 80) {
    return 'UPI display label is required (1–80 characters).';
  }
  if (input.upiMerchantName.trim().length < 1 || input.upiMerchantName.trim().length > 80) {
    return 'UPI merchant name is required (1–80 characters).';
  }
  return null;
}

function escapeCsvCell(raw: string | number): string {
  const s = String(raw ?? '');
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

export function ordersToCsv(orders: AdminOrder[]): string {
  const header = ['Case ID', 'Service', 'Platform', 'Creator', 'Contact', 'Amount INR', 'Status', 'UPI App', 'UTR Number', 'Video URL'];
  const rows = orders.map((o) =>
    [
      o.caseId,
      o.serviceTitle,
      o.platform,
      o.creatorName,
      o.contact,
      o.amountInr,
      o.status,
      o.paymentApp,
      o.utrNumber,
      o.videoUrl,
    ]
      .map(escapeCsvCell)
      .join(',')
  );
  return [header.join(','), ...rows].join('\n');
}

export function paymentsToCsv(payments: AdminPaymentRecord[]): string {
  const header = ['Payment ID', 'Case ID', 'Payer', 'UPI App', 'UTR Number', 'Amount INR', 'Status'];
  const rows = payments.map((p) =>
    [
      p.paymentId,
      p.caseId,
      p.payerName,
      p.paymentApp,
      p.utrNumber,
      p.amountInr,
      p.verificationStatus,
    ]
      .map(escapeCsvCell)
      .join(',')
  );
  return [header.join(','), ...rows].join('\n');
}
