import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeDashboardStats,
  computePaymentChannelBreakdown,
  computePlatformBreakdown,
  filterOrders,
  filterPayments,
  filterUsers,
  formatInr,
  ordersToCsv,
  paymentsToCsv,
  validateFaqInput,
  validateServicePlanInput,
  validateSettingsInput,
} from './adminLogic';
import type { AdminOrder, AdminPaymentRecord, AdminRoleRecord, AdminUserRecord } from './adminLogic';

test('computes honest zero stats when database has no records', () => {
  const stats = computeDashboardStats({
    orders: [],
    payments: [],
    users: [],
    admins: [],
  });
  assert.deepEqual(stats, {
    totalOrders: 0,
    pendingOrders: 0,
    releasedOrders: 0,
    totalPayments: 0,
    pendingPayments: 0,
    verifiedPayments: 0,
    verifiedRevenueInr: 0,
    registeredUsers: 0,
    activeAdmins: 0,
  });
});

test('computes revenue, platform breakdown, and channel breakdown accurately', () => {
  const orders: AdminOrder[] = [
    {
      caseId: 'CR-2026-1001',
      ownerUid: 'u1',
      serviceId: 'shorts-basic-claim',
      serviceTitle: 'Shorts & Single Clip Claim',
      platform: 'YouTube Shorts',
      videoUrl: 'https://youtube.com/shorts/abc',
      claimantName: 'Label X',
      creatorName: 'Creator One',
      contact: '9876543210',
      amountInr: 149,
      status: 'verifying_payment',
      paymentApp: 'phonepe',
      utrNumber: '123456789012',
      adminNotes: '',
    },
    {
      caseId: 'CR-2026-1002',
      ownerUid: 'u2',
      serviceId: 'yt-content-id',
      serviceTitle: 'YouTube Content ID Claim',
      platform: 'YouTube',
      videoUrl: 'https://youtube.com/watch?v=xyz',
      claimantName: 'Label Y',
      creatorName: 'Creator Two',
      contact: 'creator@example.com',
      amountInr: 499,
      status: 'claim_released',
      paymentApp: 'gpay',
      utrNumber: '987654321098',
      adminNotes: 'Verified',
    },
  ];

  const payments: AdminPaymentRecord[] = [
    {
      paymentId: 'pay_1',
      caseId: 'CR-2026-1001',
      ownerUid: 'u1',
      payerName: 'Creator One',
      paymentApp: 'phonepe',
      utrNumber: '123456789012',
      amountInr: 149,
      currency: 'INR',
      verificationStatus: 'pending',
      verifiedByUid: '',
      notes: '',
    },
    {
      paymentId: 'pay_2',
      caseId: 'CR-2026-1002',
      ownerUid: 'u2',
      payerName: 'Creator Two',
      paymentApp: 'gpay',
      utrNumber: '987654321098',
      amountInr: 499,
      currency: 'INR',
      verificationStatus: 'verified',
      verifiedByUid: 'admin1',
      notes: 'Matched bank ref',
    },
  ];

  const users: AdminUserRecord[] = [
    {
      uid: 'u1',
      displayName: 'Creator One',
      channelName: 'Shorts India',
      role: 'creator',
      status: 'active',
      totalCases: 1,
    },
  ];
  const admins: AdminRoleRecord[] = [
    {
      uid: 'admin1',
      email: 'shoyabidrishi77@gmail.com',
      displayName: 'Admin',
      role: 'super_admin',
      active: true,
    },
  ];

  const stats = computeDashboardStats({ orders, payments, users, admins });
  assert.equal(stats.totalOrders, 2);
  assert.equal(stats.pendingOrders, 1);
  assert.equal(stats.releasedOrders, 1);
  assert.equal(stats.verifiedPayments, 1);
  assert.equal(stats.pendingPayments, 1);
  assert.equal(stats.verifiedRevenueInr, 499);
  assert.equal(formatInr(stats.verifiedRevenueInr), '₹499');

  const platforms = computePlatformBreakdown(orders);
  assert.equal(platforms.find((p) => p.platform === 'YouTube Shorts')?.count, 1);
  assert.equal(platforms.find((p) => p.platform === 'YouTube')?.revenueInr, 499);

  const channels = computePaymentChannelBreakdown(payments);
  assert.equal(channels.find((c) => c.channel === 'gpay')?.verifiedAmountInr, 499);
  assert.equal(channels.find((c) => c.channel === 'phonepe')?.verifiedAmountInr, 0);

  assert.equal(filterOrders(orders, '987654321098', 'all', 'all').length, 1);
  assert.equal(filterPayments(payments, '', 'verified', 'gpay').length, 1);
  assert.equal(filterUsers(users, 'Shorts', 'creator', 'active').length, 1);

  assert.ok(ordersToCsv(orders).includes('CR-2026-1001'));
  assert.ok(paymentsToCsv(payments).includes('987654321098'));
});

test('validates CMS service plans, FAQs, and settings against Firestore blueprint limits', () => {
  assert.equal(
    validateServicePlanInput({
      serviceId: 'bad id!',
      code: '01',
      title: 'Valid',
      subtitle: 'Valid subtitle',
      priceInr: 149,
      turnaround: '24h',
      scope: '1 clip',
      active: true,
      sortOrder: 1,
    }) !== null,
    true
  );

  assert.equal(
    validateServicePlanInput({
      serviceId: 'shorts-basic-claim',
      code: '01',
      title: 'Shorts & Single Clip Claim',
      subtitle: 'Starter clearance for Shorts',
      priceInr: 149,
      turnaround: '6-24 hours',
      scope: '1 Short',
      active: true,
      sortOrder: 1,
    }),
    null
  );

  assert.equal(
    validateFaqInput({
      faqId: 'faq-1',
      question: 'Short',
      answer: 'Too short',
      sortOrder: 1,
      active: true,
    }),
    null
  );

  assert.equal(
    validateSettingsInput({
      settingId: 'general',
      siteName: 'CR Remover',
      supportEmail: 'invalid-email',
      supportWhatsapp: '',
      upiDisplayLabel: 'CR Remover UPI QR',
      upiMerchantName: 'CR Remover',
      maintenanceMode: false,
      allowNewOrders: true,
      strictUtrValidation: true,
    }) !== null,
    true
  );
});
