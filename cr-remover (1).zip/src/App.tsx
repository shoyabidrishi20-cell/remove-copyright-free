import { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { ProcessSection } from './components/ProcessSection';
import { CheckoutPortal } from './components/CheckoutPortal';
import { CaseTrackerSection } from './components/CaseTrackerSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import {
  CaseOrder,
  PlatformType,
  SEED_ORDERS,
  SERVICE_PLANS,
  ServicePlan,
  UpiAppId,
  createCaseOrder,
  submitPaymentProof,
  submitRazorpayPayment,
} from './utils/paymentLogic';

const STORAGE_KEY = 'cr_remover_orders_v1';

function loadInitialOrders(): CaseOrder[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return SEED_ORDERS;
    const parsed = JSON.parse(raw) as CaseOrder[];
    if (!Array.isArray(parsed) || parsed.length === 0) return SEED_ORDERS;
    return parsed;
  } catch {
    return SEED_ORDERS;
  }
}

export default function App() {
  const [orders, setOrders] = useState<CaseOrder[]>(loadInitialOrders);
  const [selectedServiceId, setSelectedServiceId] = useState<string>(SERVICE_PLANS[0].id);
  const [activeCaseId, setActiveCaseId] = useState<string | null>(null);
  const [trackerCaseId, setTrackerCaseId] = useState<string | null>(null);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
    } catch {
      // Ignore storage quota errors cleanly
    }
  }, [orders]);

  const activeOrder = activeCaseId
    ? orders.find((item) => item.caseId === activeCaseId) ?? null
    : null;

  function scrollToElement(id: string) {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  function handleSelectService(plan: ServicePlan) {
    setSelectedServiceId(plan.id);
    setActiveCaseId(null);
    scrollToElement('checkout');
  }

  function handleCreateOrder(input: {
    serviceId: string;
    platform: PlatformType;
    videoUrl: string;
    claimantName: string;
    creatorName: string;
    contact: string;
  }): CaseOrder {
    const created = createCaseOrder(input, orders);
    setOrders((prev) => [created, ...prev]);
    setActiveCaseId(created.caseId);
    return created;
  }

  function handleConfirmPayment(caseId: string, app: UpiAppId, utr: string): CaseOrder {
    const target = orders.find((o) => o.caseId === caseId);
    if (!target) {
      throw new Error(`Case ${caseId} not found`);
    }
    const updated = submitPaymentProof(target, app, utr);
    setOrders((prev) => prev.map((o) => (o.caseId === caseId ? updated : o)));
    setTrackerCaseId(caseId);
    return updated;
  }

  function handleConfirmRazorpayPayment(
    caseId: string,
    details: { razorpayOrderId: string; razorpayPaymentId: string; paidAtIso?: string }
  ): CaseOrder {
    const target = orders.find((o) => o.caseId === caseId);
    if (!target) {
      throw new Error(`Case ${caseId} not found`);
    }
    const updated = submitRazorpayPayment(target, details);
    setOrders((prev) => prev.map((o) => (o.caseId === caseId ? updated : o)));
    setTrackerCaseId(caseId);
    return updated;
  }

  function handleInspectInTracker(caseId: string) {
    setTrackerCaseId(caseId);
    scrollToElement('track');
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-[#0F172A]">
      <Navbar onStartClaim={() => scrollToElement('checkout')} />
      <main className="flex-1">
        <HeroSection
          onStartClaim={() => scrollToElement('checkout')}
          onTrackCase={() => scrollToElement('track')}
        />
        <ServicesSection
          selectedServiceId={selectedServiceId}
          onSelectService={handleSelectService}
        />
        <ProcessSection />
        <CheckoutPortal
          selectedServiceId={selectedServiceId}
          onChangeServiceId={setSelectedServiceId}
          activeOrder={activeOrder}
          onCreateOrder={handleCreateOrder}
          onConfirmPayment={handleConfirmPayment}
          onConfirmRazorpayPayment={handleConfirmRazorpayPayment}
          onResetActiveOrder={() => setActiveCaseId(null)}
          onInspectInTracker={handleInspectInTracker}
        />
        <CaseTrackerSection orders={orders} focusedCaseId={trackerCaseId} />
        <FaqSection />
      </main>
      <Footer />
    </div>
  );
}
