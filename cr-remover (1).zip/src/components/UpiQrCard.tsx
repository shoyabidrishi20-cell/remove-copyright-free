import { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { ChevronRight } from 'lucide-react';
import { QR_IMAGE_PATH } from '../utils/paymentLogic';

interface UpiQrCardProps {
  payload: string;
  sizeClass?: string;
}

export function UpiQrCard({ payload, sizeClass = 'w-full' }: UpiQrCardProps) {
  const [uploadedAvailable, setUploadedAvailable] = useState(true);
  const [generatedDataUrl, setGeneratedDataUrl] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    QRCode.toDataURL(payload, {
      errorCorrectionLevel: 'H',
      margin: 2,
      width: 420,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
    })
      .then((url) => {
        if (!cancelled) setGeneratedDataUrl(url);
      })
      .catch(() => {
        if (!cancelled) setGeneratedDataUrl(null);
      });

    return () => {
      cancelled = true;
    };
  }, [payload]);

  if (uploadedAvailable) {
    return (
      <div className="bg-black rounded-lg p-1.5 overflow-hidden">
        <img
          src={QR_IMAGE_PATH}
          alt="CR Remover UPI Payment QR Code"
          referrerPolicy="no-referrer"
          onError={() => setUploadedAvailable(false)}
          className={`${sizeClass} aspect-square block rounded-md object-contain`}
        />
      </div>
    );
  }

  return (
    <div className="bg-black rounded-lg p-2 text-white">
      <div className="relative bg-white p-1.5 rounded-md aspect-square flex items-center justify-center">
        {generatedDataUrl ? (
          <img
            src={generatedDataUrl}
            alt="CR Remover UPI Payment QR Code"
            referrerPolicy="no-referrer"
            className="w-full h-full object-contain block"
          />
        ) : (
          <div className="w-full h-full bg-slate-100 rounded" />
        )}
        <div
          aria-hidden="true"
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="w-12 h-12 rounded-full bg-black border-2 border-white flex items-center justify-center shadow-sm">
            <span className="text-white text-xl font-bold leading-none">S</span>
          </div>
        </div>
      </div>

      <div className="mt-2.5 flex items-center justify-center gap-1.5 text-xs text-slate-300 font-medium whitespace-nowrap">
        <span>CR Remover UPI QR</span>
        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
      </div>
    </div>
  );
}
