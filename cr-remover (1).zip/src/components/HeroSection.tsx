import { useState } from 'react';
import { ArrowRight, ShieldCheck } from 'lucide-react';
import heroStudioImage from '../assets/images/creator_studio_workspace_1794602625929.jpg';

interface HeroSectionProps {
  onStartClaim: () => void;
  onTrackCase: () => void;
}

export function HeroSection({ onStartClaim, onTrackCase }: HeroSectionProps) {
  const [imgFailed, setImgFailed] = useState(false);

  const metrics = [
    { value: '4,820+', label: 'Claims & strikes resolved' },
    { value: '24–72 hr', label: 'Typical Content ID turnaround' },
    { value: '100%', label: 'Zero channel password needed' },
    { value: 'UPI Direct', label: 'QR, GPay, PhonePe & Paytm' },
  ];

  return (
    <section id="top" className="pt-10 pb-14 sm:pt-14 sm:pb-16 border-b border-slate-200/80 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-between py-2">
            <div>
              <p className="text-sm font-medium text-slate-500 tracking-tight mb-4">
                Creator Rights Desk · YouTube, Reels &amp; Facebook
              </p>
              <h1
                className="font-bold tracking-tight text-slate-950 leading-[1.08] mb-5"
                style={{ fontSize: 'clamp(2.25rem, 4vw, 3.5rem)', textWrap: 'balance' }}
              >
                Fast, verified copyright claim &amp; strike removal for creators.
              </h1>
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl mb-8">
                Clear false Content ID claims, muted Reels audio blocks, and active copyright strikes
                without sharing channel logins. Pay securely in INR using our verified UPI QR,
                Google Pay, PhonePe, or Paytm.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-5">
              <button
                type="button"
                onClick={onStartClaim}
                className="inline-flex items-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-white bg-[#1E40AF] hover:bg-[#1E3A8A] rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#1E40AF]"
              >
                <span>Remove a Copyright Claim</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onTrackCase}
                className="inline-flex items-center gap-1.5 py-2 text-sm font-semibold text-slate-700 hover:text-[#1E40AF] underline underline-offset-4 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Track Existing Case
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full min-h-[260px] lg:min-h-[380px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100 relative">
              {!imgFailed ? (
                <img
                  src={heroStudioImage}
                  alt="Creator workstation showing calibrated video editing timeline and studio microphone"
                  referrerPolicy="no-referrer"
                  onError={() => setImgFailed(true)}
                  className="w-full h-full object-cover lg:h-full"
                />
              ) : (
                <div className="w-full h-full min-h-[260px] flex flex-col items-center justify-center bg-slate-900 text-slate-100 p-8 text-center">
                  <ShieldCheck className="w-10 h-10 text-blue-400 mb-3" />
                  <p className="text-base font-semibold">CR Remover Rights Desk</p>
                  <p className="text-sm text-slate-400 mt-1">
                    Audio, visual &amp; DMCA claim clearance for creators
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-200 grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {metrics.map((item) => (
            <div key={item.label} className="space-y-1">
              <div className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950 font-mono tabular-nums">
                {item.value}
              </div>
              <div className="text-sm text-slate-600">{item.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
