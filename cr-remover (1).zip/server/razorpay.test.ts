import test from 'node:test';
import assert from 'node:assert/strict';
import {
  RazorpayApiError,
  computeRazorpaySignature,
  formatRazorpayApiError,
  getRazorpayConfigStatus,
  getServerRazorpayCredentials,
  getServerServicePlan,
  isValidCaseId,
  sanitizeSecretValue,
  validateRazorpayOrderRequest,
  validateRazorpayVerifyRequest,
  verifyRazorpaySignature,
  verifyRazorpayWebhookSignature,
} from './razorpay';

test('resolves authoritative server-side plan pricing in INR', () => {
  assert.equal(getServerServicePlan('shorts-basic-claim')?.priceInr, 149);
  assert.equal(getServerServicePlan('reels-audio-unblock')?.priceInr, 399);
  assert.equal(getServerServicePlan('yt-content-id')?.priceInr, 499);
  assert.equal(getServerServicePlan('copyright-strike')?.priceInr, 1499);
  assert.equal(getServerServicePlan('channel-cleanup-pack')?.priceInr, 1999);
  assert.equal(getServerServicePlan('tampered-plan'), null);
});

test('detects Razorpay test configuration cleanly without exposing any API keys or live mode', () => {
  const unconfigured = getRazorpayConfigStatus({});
  assert.deepEqual(unconfigured, {
    configured: false,
    mode: 'not_configured',
  });
  assert.deepEqual(Object.keys(unconfigured).sort(), ['configured', 'mode']);

  const partial = getRazorpayConfigStatus({ RAZORPAY_KEY_ID: 'rzp_test_12345' });
  assert.deepEqual(partial, {
    configured: false,
    mode: 'not_configured',
  });

  const testMode = getRazorpayConfigStatus({
    RAZORPAY_KEY_ID: 'rzp_test_abc123',
    RAZORPAY_KEY_SECRET: 'super_secret_value',
  });
  assert.deepEqual(testMode, {
    configured: true,
    mode: 'test',
  });
  assert.equal('keyId' in testMode, false);
  assert.equal('keySecret' in testMode, false);

  const liveBlocked = getRazorpayConfigStatus({
    RAZORPAY_KEY_ID: 'rzp_live_xyz999',
    RAZORPAY_KEY_SECRET: 'live_secret',
  });
  assert.deepEqual(liveBlocked, {
    configured: false,
    mode: 'not_configured',
  });

  const viteIgnored = getRazorpayConfigStatus({
    VITE_RAZORPAY_KEY_ID: 'rzp_test_vite123',
    RAZORPAY_KEY_SECRET: 'test_secret',
  });
  assert.deepEqual(viteIgnored, {
    configured: false,
    mode: 'not_configured',
  });

  const credsMissing = getServerRazorpayCredentials({});
  assert.equal(credsMissing.ok, false);
  if (!credsMissing.ok) {
    assert.equal(credsMissing.statusCode, 503);
  }

  const credsLiveRejected = getServerRazorpayCredentials({
    RAZORPAY_KEY_ID: 'rzp_live_xyz999',
    RAZORPAY_KEY_SECRET: 'live_secret',
  });
  assert.equal(credsLiveRejected.ok, false);
  if (!credsLiveRejected.ok) {
    assert.equal(credsLiveRejected.statusCode, 403);
  }

  const credsValid = getServerRazorpayCredentials({
    RAZORPAY_KEY_ID: 'rzp_test_abc123',
    RAZORPAY_KEY_SECRET: 'super_secret_value',
  });
  assert.equal(credsValid.ok, true);
  if (credsValid.ok) {
    assert.equal(credsValid.mode, 'test');
  }
});

test('verifies Razorpay payment HMAC-SHA256 signatures and rejects tampered payloads', () => {
  const secret = 'test_webhook_secret_key';
  const orderId = 'order_Q1A2B3C4D5E6';
  const paymentId = 'pay_Z9Y8X7W6V5U4';
  const validSignature = computeRazorpaySignature({ orderId, paymentId, secret });

  assert.equal(
    verifyRazorpaySignature({
      orderId,
      paymentId,
      signature: validSignature,
      secret,
    }),
    true
  );

  assert.equal(
    verifyRazorpaySignature({
      orderId: 'order_TAMPERED',
      paymentId,
      signature: validSignature,
      secret,
    }),
    false
  );

  assert.equal(
    verifyRazorpaySignature({
      orderId,
      paymentId,
      signature: validSignature.replace(/^./, validSignature[0] === 'a' ? 'b' : 'a'),
      secret,
    }),
    false
  );

  assert.equal(
    verifyRazorpaySignature({
      orderId,
      paymentId,
      signature: 'short',
      secret,
    }),
    false
  );
});

test('verifies Razorpay webhook payload signatures', () => {
  const rawBody = JSON.stringify({ event: 'payment.captured', payload: { id: 'pay_123' } });
  const secret = 'whsec_test';
  const sig = computeRazorpaySignature({
    orderId: 'unused',
    paymentId: 'unused',
    secret,
  });

  // Ensure mismatched signature fails cleanly
  assert.equal(verifyRazorpayWebhookSignature({ rawBody, signature: sig, secret }), false);
});

test('formats Razorpay API errors into readable messages without raw JSON dumps', () => {
  const authErr = formatRazorpayApiError(
    401,
    JSON.stringify({ error: { description: 'Authentication failed', code: 'BAD_REQUEST_ERROR' } })
  );
  assert.match(authErr, /Razorpay authentication failed/i);
  assert.equal(authErr.includes('{'), false);

  const badReq = formatRazorpayApiError(
    400,
    JSON.stringify({ error: { description: 'Amount exceeds maximum allowed' } })
  );
  assert.equal(badReq, 'Razorpay order creation failed: Amount exceeds maximum allowed');
});

test('sanitizes accidental quotes and whitespace in server-side Razorpay secrets', () => {
  assert.equal(sanitizeSecretValue(' "rzp_test_123" '), 'rzp_test_123');
  assert.equal(sanitizeSecretValue(" 'secret_abc'\n"), 'secret_abc');
  assert.equal(sanitizeSecretValue(undefined), '');
});

test('validates Case ID, service plan, and authoritative INR amount on Razorpay order requests', () => {
  assert.equal(isValidCaseId('CR-2026-1042'), true);
  assert.equal(isValidCaseId('INVALID-123'), false);

  const badCase = validateRazorpayOrderRequest({
    caseId: 'bad-id',
    serviceId: 'shorts-basic-claim',
  });
  assert.equal(badCase.ok, false);

  const badPlan = validateRazorpayOrderRequest({
    caseId: 'CR-2026-1042',
    serviceId: 'unknown-plan',
  });
  assert.equal(badPlan.ok, false);

  const tamperedAmount = validateRazorpayOrderRequest({
    caseId: 'CR-2026-1042',
    serviceId: 'yt-content-id',
    amountInr: 1,
  });
  assert.equal(tamperedAmount.ok, false);

  const valid = validateRazorpayOrderRequest({
    caseId: 'CR-2026-1042',
    serviceId: 'yt-content-id',
    amountInr: 499,
    platform: 'YouTube',
    creatorName: 'Aarav',
  });
  assert.equal(valid.ok, true);
  if (valid.ok) {
    assert.equal(valid.data.amountInr, 499);
    assert.equal(valid.data.amountPaise, 49900);
  }
});

test('validates Razorpay verify payloads strictly', () => {
  const missingFields = validateRazorpayVerifyRequest({ caseId: 'CR-2026-1042' });
  assert.equal(missingFields.ok, false);

  const badOrderId = validateRazorpayVerifyRequest({
    caseId: 'CR-2026-1042',
    razorpayOrderId: 'bad_123',
    razorpayPaymentId: 'pay_123456',
    razorpaySignature: 'sig123',
  });
  assert.equal(badOrderId.ok, false);

  const ok = validateRazorpayVerifyRequest({
    caseId: 'CR-2026-1042',
    razorpayOrderId: 'order_Test12345',
    razorpayPaymentId: 'pay_Test67890',
    razorpaySignature: 'abcdef123456',
  });
  assert.equal(ok.ok, true);
});

test('RazorpayApiError preserves non-502 HTTP 400 status code for reverse proxy compatibility', () => {
  const err = new RazorpayApiError('Auth failed', 400);
  assert.equal(err.name, 'RazorpayApiError');
  assert.equal(err.statusCode, 400);
  assert.equal(err.message, 'Auth failed');
});
