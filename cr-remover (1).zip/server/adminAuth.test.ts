import test from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {
  evaluateAdminAuthorization,
  extractBearerToken,
  isValidFirebaseUid,
  parseAllowedAdminEmails,
  verifyFirebaseIdTokenWithCerts,
} from './adminAuth';

function toBase64Url(input: Buffer | string): string {
  const buf = typeof input === 'string' ? Buffer.from(input, 'utf8') : input;
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function createSignedJwt(
  payload: Record<string, unknown>,
  privateKeyPem: string,
  kid = 'test-key-1',
  alg = 'RS256'
): string {
  const header = toBase64Url(JSON.stringify({ alg, kid, typ: 'JWT' }));
  const body = toBase64Url(JSON.stringify(payload));
  const signingInput = `${header}.${body}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(signingInput);
  signer.end();
  const signature = signer.sign(privateKeyPem);
  return `${signingInput}.${toBase64Url(signature)}`;
}

test('parses allowed admin emails with secure default fallback', () => {
  assert.deepEqual(parseAllowedAdminEmails(undefined), ['shoyabidrishi77@gmail.com']);
  assert.deepEqual(parseAllowedAdminEmails('Admin@Example.com, ops@example.com '), [
    'admin@example.com',
    'ops@example.com',
  ]);
});

test('validates Firebase UIDs against ID poisoning patterns', () => {
  assert.equal(isValidFirebaseUid('uid_123-ABC'), true);
  assert.equal(isValidFirebaseUid('../etc/passwd'), false);
  assert.equal(isValidFirebaseUid(''), false);
  assert.equal(isValidFirebaseUid('a'.repeat(129)), false);
});

test('extracts Bearer token cleanly', () => {
  assert.equal(extractBearerToken('Bearer abc.def.ghi'), 'abc.def.ghi');
  assert.equal(extractBearerToken('Basic xyz'), null);
  assert.equal(extractBearerToken(undefined), null);
});

test('verifies RS256 Firebase ID tokens and rejects expired, spoofed, or unverified tokens', () => {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });

  const projectId = 'marklar-objective-pcbh2';
  const now = 1794600000;
  const certs = { 'test-key-1': publicKey };

  const validJwt = createSignedJwt(
    {
      iss: `https://securetoken.google.com/${projectId}`,
      aud: projectId,
      sub: 'adminUserUid_01',
      email: 'shoyabidrishi77@gmail.com',
      email_verified: true,
      name: 'Shoyab Idrishi',
      iat: now - 30,
      auth_time: now - 30,
      exp: now + 3600,
    },
    privateKey
  );

  const verified = verifyFirebaseIdTokenWithCerts(validJwt, projectId, certs, now);
  assert.equal(verified.uid, 'adminUserUid_01');
  assert.equal(verified.email, 'shoyabidrishi77@gmail.com');
  assert.equal(verified.emailVerified, true);

  // Reject unverified email spoof attempt
  const unverifiedJwt = createSignedJwt(
    {
      iss: `https://securetoken.google.com/${projectId}`,
      aud: projectId,
      sub: 'attackerUid_01',
      email: 'shoyabidrishi77@gmail.com',
      email_verified: false,
      iat: now - 30,
      auth_time: now - 30,
      exp: now + 3600,
    },
    privateKey
  );
  assert.throws(
    () => verifyFirebaseIdTokenWithCerts(unverifiedJwt, projectId, certs, now),
    /Verified administrator email is required/
  );

  // Reject expired token
  const expiredJwt = createSignedJwt(
    {
      iss: `https://securetoken.google.com/${projectId}`,
      aud: projectId,
      sub: 'adminUserUid_01',
      email: 'shoyabidrishi77@gmail.com',
      email_verified: true,
      iat: now - 4000,
      auth_time: now - 4000,
      exp: now - 10,
    },
    privateKey
  );
  assert.throws(() => verifyFirebaseIdTokenWithCerts(expiredJwt, projectId, certs, now), /expired/);

  // Reject wrong audience
  const wrongAudJwt = createSignedJwt(
    {
      iss: `https://securetoken.google.com/${projectId}`,
      aud: 'other-project',
      sub: 'adminUserUid_01',
      email: 'shoyabidrishi77@gmail.com',
      email_verified: true,
      iat: now - 30,
      auth_time: now - 30,
      exp: now + 3600,
    },
    privateKey
  );
  assert.throws(() => verifyFirebaseIdTokenWithCerts(wrongAudJwt, projectId, certs, now), /audience/);
});

test('authorizes bootstrapped admin or active Firestore admin role and rejects unauthorized users', () => {
  const allowedEmails = ['shoyabidrishi77@gmail.com'];

  const primary = evaluateAdminAuthorization({
    token: {
      uid: 'u1',
      email: 'shoyabidrishi77@gmail.com',
      emailVerified: true,
      name: 'Admin',
      authTime: 100,
      expiresAt: 999999,
      rawClaims: {},
    },
    allowedEmails,
  });
  assert.deepEqual(primary, { authorized: true, role: 'super_admin' });

  const delegated = evaluateAdminAuthorization({
    token: {
      uid: 'u2',
      email: 'ops@crremover.in',
      emailVerified: true,
      name: 'Ops Admin',
      authTime: 100,
      expiresAt: 999999,
      rawClaims: {},
    },
    allowedEmails,
    firestoreAdminRecord: { active: true, role: 'admin' },
  });
  assert.deepEqual(delegated, { authorized: true, role: 'admin' });

  const outsider = evaluateAdminAuthorization({
    token: {
      uid: 'u3',
      email: 'random@gmail.com',
      emailVerified: true,
      name: 'Random',
      authTime: 100,
      expiresAt: 999999,
      rawClaims: {},
    },
    allowedEmails,
    firestoreAdminRecord: null,
  });
  assert.equal(outsider.authorized, false);
});
