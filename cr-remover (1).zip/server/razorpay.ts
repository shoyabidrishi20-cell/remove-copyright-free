import crypto from 'node:crypto';

export interface ServerServicePlan {
  id: string;
  title: string;
  priceInr: number;
}

export const SERVER_SERVICE_PLANS: Record<string, ServerServicePlan> = {
  'shorts-basic-claim': {
    id: 'shorts-basic-claim',
    title: 'Shorts & Single Clip Claim',
    priceInr: 149,
  },
  'reels-audio-unblock': {
    id: 'reels-audio-unblock',
    title: 'Instagram Reels Audio Unblock',
    priceInr: 399,
  },
  'yt-content-id': {
    id: 'yt-content-id',
    title: 'YouTube Content ID Claim',
    priceInr: 499,
  },
  'copyright-strike': {
    id: 'copyright-strike',
    title: 'Copyright Strike Retraction',
    priceInr: 1499,
  },
  'channel-cleanup-pack': {
    id: 'channel-cleanup-pack',
    title: 'Channel Clean-Up Pack',
    priceInr: 1999,
  },
};

export interface RazorpayGatewayStatus {
  configured: boolean;
  mode: 'test' | 'not_configured';
}

export type ServerRazorpayCredentialsResult =
  | {
      ok: true;
      keyId: string;
      keySecret: string;
      mode: 'test';
    }
  | {
      ok: false;
      statusCode: 403 | 503;
      error: string;
    };

export function sanitizeSecretValue(raw?: string): string {
  const trimmed = (raw ?? '').trim();
  if (
    (trimmed.startsWith('"') && trimmed.endsWith('"')) ||
    (trimmed.startsWith("'") && trimmed.endsWith("'"))
  ) {
    return trimmed.slice(1, -1).trim();
  }
  return trimmed;
}

export function isValidCaseId(caseId: string): boolean {
  return typeof caseId === 'string' && /^CR-\d{4}-\d{4,6}$/.test(caseId.trim());
}

export interface ValidatedOrderInput {
  caseId: string;
  plan: ServerServicePlan;
  amountInr: number;
  amountPaise: number;
  platform: string;
  creatorName: string;
}

export function validateRazorpayOrderRequest(
  rawBody: unknown
): { ok: true; data: ValidatedOrderInput } | { ok: false; error: string } {
  const body = (rawBody && typeof rawBody === 'object' ? rawBody : {}) as Record<string, unknown>;
  const caseId = String(body.caseId ?? '').trim();
  const serviceId = String(body.serviceId ?? '').trim();
  const platform = String(body.platform ?? '').trim();
  const creatorName = String(body.creatorName ?? '').trim();

  if (!isValidCaseId(caseId)) {
    return {
      ok: false,
      error: 'Valid Case ID (e.g. CR-2026-1042) is required before creating a Razorpay order.',
    };
  }

  const plan = getServerServicePlan(serviceId);
  if (!plan) {
    return { ok: false, error: 'Unknown or invalid removal service plan.' };
  }

  if (body.amountInr !== undefined && body.amountInr !== null && body.amountInr !== '') {
    const clientAmount = Number(body.amountInr);
    if (!Number.isFinite(clientAmount) || clientAmount !== plan.priceInr) {
      return {
        ok: false,
        error: `Payment amount mismatch for ${plan.title}. Expected ₹${plan.priceInr}.`,
      };
    }
  }

  const amountPaise = Math.round(plan.priceInr * 100);
  return {
    ok: true,
    data: {
      caseId,
      plan,
      amountInr: plan.priceInr,
      amountPaise,
      platform: platform.slice(0, 40),
      creatorName: creatorName.slice(0, 80),
    },
  };
}

export function validateRazorpayVerifyRequest(
  rawBody: unknown
):
  | {
      ok: true;
      data: {
        caseId: string;
        razorpayOrderId: string;
        razorpayPaymentId: string;
        razorpaySignature: string;
      };
    }
  | { ok: false; error: string } {
  const body = (rawBody && typeof rawBody === 'object' ? rawBody : {}) as Record<string, unknown>;
  const caseId = String(body.caseId ?? '').trim();
  const razorpayOrderId = String(body.razorpayOrderId ?? '').trim();
  const razorpayPaymentId = String(body.razorpayPaymentId ?? '').trim();
  const razorpaySignature = String(body.razorpaySignature ?? '').trim();

  if (!isValidCaseId(caseId)) {
    return { ok: false, error: 'Valid Case ID (e.g. CR-2026-1042) is required.' };
  }
  if (!razorpayOrderId || !razorpayPaymentId || !razorpaySignature) {
    return {
      ok: false,
      error: 'razorpayOrderId, razorpayPaymentId, and razorpaySignature are required.',
    };
  }
  if (!/^order_[A-Za-z0-9]{4,40}$/.test(razorpayOrderId)) {
    return { ok: false, error: 'Invalid Razorpay Order ID format.' };
  }
  if (!/^pay_[A-Za-z0-9]{4,40}$/.test(razorpayPaymentId)) {
    return { ok: false, error: 'Invalid Razorpay Payment ID format.' };
  }

  return {
    ok: true,
    data: { caseId, razorpayOrderId, razorpayPaymentId, razorpaySignature },
  };
}

export function getServerServicePlan(serviceId: string): ServerServicePlan | null {
  if (!serviceId || typeof serviceId !== 'string') return null;
  return SERVER_SERVICE_PLANS[serviceId.trim()] ?? null;
}

export function getRazorpayConfigStatus(
  env: Record<string, string | undefined> = process.env
): RazorpayGatewayStatus {
  const keyId = sanitizeSecretValue(env.RAZORPAY_KEY_ID);
  const keySecret = sanitizeSecretValue(env.RAZORPAY_KEY_SECRET);

  if (!keyId || !keySecret || !keyId.startsWith('rzp_test_')) {
    return {
      configured: false,
      mode: 'not_configured',
    };
  }

  return {
    configured: true,
    mode: 'test',
  };
}

export function getServerRazorpayCredentials(
  env: Record<string, string | undefined> = process.env
): ServerRazorpayCredentialsResult {
  const keyId = sanitizeSecretValue(env.RAZORPAY_KEY_ID);
  const keySecret = sanitizeSecretValue(env.RAZORPAY_KEY_SECRET);

  if (!keyId || !keySecret) {
    return {
      ok: false,
      statusCode: 503,
      error:
        'Razorpay credentials (RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET) are not configured on the server yet.',
    };
  }

  if (keyId.startsWith('rzp_live_') || !keyId.startsWith('rzp_test_')) {
    return {
      ok: false,
      statusCode: 403,
      error:
        'Live Razorpay payments are disabled. Configure Razorpay TEST MODE keys (rzp_test_...) on the server.',
    };
  }

  return {
    ok: true,
    keyId,
    keySecret,
    mode: 'test',
  };
}

export function computeRazorpaySignature(params: {
  orderId: string;
  paymentId: string;
  secret: string;
}): string {
  return crypto
    .createHmac('sha256', params.secret)
    .update(`${params.orderId}|${params.paymentId}`)
    .digest('hex');
}

export function verifyRazorpaySignature(params: {
  orderId: string;
  paymentId: string;
  signature: string;
  secret: string;
}): boolean {
  const orderId = params.orderId.trim();
  const paymentId = params.paymentId.trim();
  const signature = params.signature.trim();
  const secret = params.secret.trim();

  if (!orderId || !paymentId || !signature || !secret) {
    return false;
  }

  const expected = computeRazorpaySignature({ orderId, paymentId, secret });
  const expectedBuf = Buffer.from(expected, 'utf8');
  const providedBuf = Buffer.from(signature, 'utf8');
  if (expectedBuf.length !== providedBuf.length) {
    return false;
  }
  return crypto.timingSafeEqual(expectedBuf, providedBuf);
}

export function verifyRazorpayWebhookSignature(params: {
  rawBody: string;
  signature: string;
  secret: string;
}): boolean {
  if (!params.rawBody || !params.signature.trim() || !params.secret.trim()) {
    return false;
  }
  const expected = crypto
    .createHmac('sha256', params.secret.trim())
    .update(params.rawBody)
    .digest('hex');
  const expectedBuf = Buffer.from(expected, 'utf8');
  const providedBuf = Buffer.from(params.signature.trim(), 'utf8');
  if (expectedBuf.length !== providedBuf.length) {
    return false;
  }
  return crypto.timingSafeEqual(expectedBuf, providedBuf);
}

export interface RazorpayOrderApiResponse {
  id: string;
  entity: string;
  amount: number;
  amount_paid: number;
  amount_due: number;
  currency: string;
  receipt: string;
  status: string;
}

export class RazorpayApiError extends Error {
  statusCode: number;

  constructor(message: string, statusCode = 400) {
    super(message);
    this.name = 'RazorpayApiError';
    this.statusCode = statusCode;
  }
}

export function formatRazorpayApiError(status: number, errText: string): string {
  let description = '';
  try {
    const parsed = JSON.parse(errText) as { error?: { description?: string } };
    description = parsed?.error?.description?.trim() ?? '';
  } catch {
    description = errText.trim();
  }

  if (status === 401) {
    return 'Razorpay authentication failed. Verify that RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in your environment secrets are a valid matching key pair.';
  }
  return description
    ? `Razorpay order creation failed: ${description}`
    : `Razorpay order creation failed (HTTP ${status}).`;
}

export async function createRazorpayOrderOnApi(params: {
  keyId: string;
  keySecret: string;
  amountInr: number;
  receipt: string;
  notes?: Record<string, string>;
}): Promise<RazorpayOrderApiResponse> {
  const amountPaise = Math.round(params.amountInr * 100);
  if (!Number.isFinite(amountPaise) || amountPaise < 100) {
    throw new RazorpayApiError('Order amount must be at least ₹1 (100 paise).', 400);
  }

  const basicAuth = Buffer.from(`${params.keyId}:${params.keySecret}`).toString('base64');
  let response: Response;
  try {
    response = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        Authorization: `Basic ${basicAuth}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: amountPaise,
        currency: 'INR',
        receipt: params.receipt.slice(0, 40),
        notes: params.notes ?? {},
      }),
    });
  } catch (err) {
    const detail = err instanceof Error ? err.message : 'Network error contacting Razorpay.';
    throw new RazorpayApiError(`Unable to reach Razorpay API: ${detail}`, 400);
  }

  if (!response.ok) {
    const errText = await response.text();
    throw new RazorpayApiError(formatRazorpayApiError(response.status, errText), 400);
  }

  return (await response.json()) as RazorpayOrderApiResponse;
}
